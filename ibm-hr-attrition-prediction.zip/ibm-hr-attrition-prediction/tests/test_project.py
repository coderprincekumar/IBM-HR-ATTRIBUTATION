import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from make_synthetic_data import make  # noqa: E402
from src import modeling, roi  # noqa: E402
from src.config import TARGET, BusinessAssumptions  # noqa: E402
from src.data import clean  # noqa: E402


def test_clean_drops_constant_columns_and_encodes_target():
    df = clean(make(300))
    for col in ["EmployeeCount", "EmployeeNumber", "Over18", "StandardHours"]:
        assert col not in df.columns
    assert set(df[TARGET].unique()) <= {0, 1}


def test_net_benefit_arithmetic():
    a = BusinessAssumptions(replacement_cost_multiplier=1.5, intervention_cost=1000,
                            intervention_success_rate=0.5)
    y = np.array([1, 0, 1, 0])
    flagged = np.array([1, 1, 0, 0])
    salary = np.array([100_000, 50_000, 80_000, 60_000])
    r = roi.net_benefit(y, flagged, salary, a)
    # one leaver caught: 100k * 1.5 * 0.5 = 75k saved; 2 people flagged = 2k cost
    assert r["gross_savings"] == 75_000
    assert r["program_cost"] == 2_000
    assert r["net_benefit"] == 73_000


def test_do_nothing_costs_nothing():
    a = BusinessAssumptions()
    r = roi.net_benefit(np.array([1, 0]), np.array([0, 0]), np.array([1.0, 1.0]), a)
    assert r["net_benefit"] == 0


def test_pipeline_fits_and_predicts_probabilities():
    df = clean(make(400))
    X_train, X_test, y_train, y_test = modeling.split(df)
    model = modeling.make_pipeline(modeling.candidates()["Logistic Regression"], X_train)
    model.fit(X_train, y_train)
    p = model.predict_proba(X_test)[:, 1]
    assert p.shape == (len(X_test),) and ((p >= 0) & (p <= 1)).all()
