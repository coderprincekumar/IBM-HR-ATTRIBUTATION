"""Generate a FAKE dataset with the same schema as the IBM HR file.

Only for smoke-testing the pipeline (CI / no internet). Never report results
from it - use the real Kaggle CSV for the actual project.
"""
import numpy as np
import pandas as pd


def make(n=1470, seed=0) -> pd.DataFrame:
    r = np.random.default_rng(seed)
    age = r.integers(18, 60, n)
    level = r.integers(1, 6, n)
    income = (level * 2500 + r.normal(2000, 800, n)).clip(1009, 20000).astype(int)
    overtime = r.choice(["Yes", "No"], n, p=[0.28, 0.72])
    marital = r.choice(["Single", "Married", "Divorced"], n, p=[0.32, 0.46, 0.22])
    travel = r.choice(["Travel_Rarely", "Travel_Frequently", "Non-Travel"], n, p=[0.7, 0.19, 0.11])
    z = (-2.2 + 1.1 * (overtime == "Yes") + 0.8 * (marital == "Single")
         + 0.5 * (travel == "Travel_Frequently") - 0.0002 * (income - 6000)
         - 0.02 * (age - 35))
    left = r.random(n) < 1 / (1 + np.exp(-z))
    yrs = r.integers(0, 30, n)
    df = pd.DataFrame({
        "Age": age, "Attrition": np.where(left, "Yes", "No"), "BusinessTravel": travel,
        "DailyRate": r.integers(100, 1500, n),
        "Department": r.choice(["Sales", "Research & Development", "Human Resources"], n, p=[.3, .65, .05]),
        "DistanceFromHome": r.integers(1, 30, n), "Education": r.integers(1, 6, n),
        "EducationField": r.choice(["Life Sciences", "Medical", "Marketing", "Technical Degree", "Other", "Human Resources"], n),
        "EmployeeCount": 1, "EmployeeNumber": np.arange(1, n + 1),
        "EnvironmentSatisfaction": r.integers(1, 5, n), "Gender": r.choice(["Male", "Female"], n),
        "HourlyRate": r.integers(30, 100, n), "JobInvolvement": r.integers(1, 5, n),
        "JobLevel": level,
        "JobRole": r.choice(["Sales Executive", "Research Scientist", "Laboratory Technician", "Manager", "Healthcare Representative", "Sales Representative"], n),
        "JobSatisfaction": r.integers(1, 5, n), "MaritalStatus": marital, "MonthlyIncome": income,
        "MonthlyRate": r.integers(2000, 27000, n), "NumCompaniesWorked": r.integers(0, 10, n),
        "Over18": "Y", "OverTime": overtime, "PercentSalaryHike": r.integers(11, 26, n),
        "PerformanceRating": r.choice([3, 4], n, p=[.85, .15]),
        "RelationshipSatisfaction": r.integers(1, 5, n), "StandardHours": 80,
        "StockOptionLevel": r.integers(0, 4, n), "TotalWorkingYears": yrs,
        "TrainingTimesLastYear": r.integers(0, 7, n), "WorkLifeBalance": r.integers(1, 5, n),
        "YearsAtCompany": np.minimum(yrs, r.integers(0, 20, n)),
        "YearsInCurrentRole": r.integers(0, 15, n), "YearsSinceLastPromotion": r.integers(0, 12, n),
        "YearsWithCurrManager": r.integers(0, 15, n),
    })
    return df


if __name__ == "__main__":
    import sys
    make().to_csv(sys.argv[1] if len(sys.argv) > 1 else "synthetic.csv", index=False)
