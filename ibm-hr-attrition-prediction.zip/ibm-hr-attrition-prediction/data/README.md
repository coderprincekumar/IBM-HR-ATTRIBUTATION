# Data

Dataset: **IBM HR Analytics Employee Attrition & Performance** (1,470 employees, 35 columns).
It is a fictional dataset created by IBM data scientists and published on Kaggle.

1. Download `WA_Fn-UseC_-HR-Employee-Attrition.csv` from Kaggle
   (search "IBM HR Analytics Employee Attrition & Performance").
2. Put it in `data/raw/`.

The CSV is git-ignored so the repo does not redistribute the data.
