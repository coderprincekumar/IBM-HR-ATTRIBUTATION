"""Loading and light cleaning of the IBM HR Attrition dataset."""
from pathlib import Path

import pandas as pd

from .config import DROP_COLS, TARGET

REQUIRED = {TARGET, "MonthlyIncome", "OverTime", "Age", "JobRole"}


def load_data(path: Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}.\n"
            "Download 'WA_Fn-UseC_-HR-Employee-Attrition.csv' from Kaggle "
            "(IBM HR Analytics Employee Attrition & Performance) and place it "
            "in data/raw/. See data/README.md."
        )
    df = pd.read_csv(path)
    missing = REQUIRED - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing expected columns: {sorted(missing)}")
    return df


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Drop useless columns, encode the target as 1 = left, 0 = stayed."""
    out = df.drop(columns=[c for c in DROP_COLS if c in df.columns]).copy()
    out[TARGET] = out[TARGET].map({"Yes": 1, "No": 0}).astype(int)
    return out.drop_duplicates().reset_index(drop=True)
