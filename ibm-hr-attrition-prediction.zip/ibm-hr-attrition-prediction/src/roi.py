"""Business value of the model: expected savings vs. cost of retention actions.

Logic: flag employees the model thinks will leave -> run a retention action on
each flagged person (costs money) -> a share of the flagged *real* leavers stay
(saves their replacement cost). Everything is computed from the data plus the
assumptions in config.BusinessAssumptions.
"""
import numpy as np
import pandas as pd

from .config import BusinessAssumptions


def annual_salary(df: pd.DataFrame) -> np.ndarray:
    return (df["MonthlyIncome"] * 12).to_numpy(dtype=float)


def net_benefit(y_true, flagged, salary, a: BusinessAssumptions) -> dict:
    y = np.asarray(y_true).astype(bool)
    f = np.asarray(flagged).astype(bool)
    replacement = np.asarray(salary) * a.replacement_cost_multiplier
    tp = y & f
    gross = replacement[tp].sum() * a.intervention_success_rate
    cost = f.sum() * a.intervention_cost
    return {
        "flagged": int(f.sum()),
        "true_leavers_caught": int(tp.sum()),
        "gross_savings": float(gross),
        "program_cost": float(cost),
        "net_benefit": float(gross - cost),
    }


def best_threshold(y_true, proba, salary, a: BusinessAssumptions):
    """Pick the probability cut-off that maximises net benefit."""
    grid = np.linspace(0.05, 0.95, 91)
    values = [net_benefit(y_true, proba >= t, salary, a)["net_benefit"] for t in grid]
    return float(grid[int(np.argmax(values))])


def strategy_table(y_true, proba, salary, threshold, a: BusinessAssumptions) -> pd.DataFrame:
    n = len(y_true)
    rows = {
        f"Model (threshold {threshold:.2f})": proba >= threshold,
        "Model (threshold 0.50)": proba >= 0.5,
        "Intervene on everyone": np.ones(n, dtype=bool),
        "Do nothing": np.zeros(n, dtype=bool),
    }
    return pd.DataFrame({k: net_benefit(y_true, v, salary, a) for k, v in rows.items()}).T


def sensitivity(y_true, flagged, salary, a: BusinessAssumptions,
                success_rates=(0.1, 0.2, 0.3, 0.5), costs=(1000, 2500, 5000, 10000)) -> pd.DataFrame:
    """Net benefit under different assumptions (rows = success rate, cols = cost)."""
    out = {}
    for c in costs:
        out[f"cost ${c:,}"] = [
            net_benefit(y_true, flagged, salary,
                        BusinessAssumptions(a.replacement_cost_multiplier, c, s))["net_benefit"]
            for s in success_rates
        ]
    return pd.DataFrame(out, index=[f"success {s:.0%}" for s in success_rates])
