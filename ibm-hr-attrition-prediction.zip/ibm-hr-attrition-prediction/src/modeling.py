"""Model comparison, tuning and selection. All preprocessing lives inside the
sklearn Pipeline so it is fitted on training folds only (no data leakage)."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import (RandomizedSearchCV, StratifiedKFold,
                                     cross_validate, train_test_split)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .config import SEED, TARGET, TEST_SIZE


def split(df):
    X, y = df.drop(columns=[TARGET]), df[TARGET]
    return train_test_split(X, y, test_size=TEST_SIZE, stratify=y, random_state=SEED)


def make_pipeline(estimator, X: pd.DataFrame) -> Pipeline:
    cat = X.select_dtypes(exclude="number").columns.tolist()
    num = X.select_dtypes(include="number").columns.tolist()
    pre = ColumnTransformer([
        ("num", StandardScaler(), num),
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat),
    ])
    return Pipeline([("prep", pre), ("model", estimator)])


def candidates():
    return {
        "Logistic Regression": LogisticRegression(
            class_weight="balanced", max_iter=3000, random_state=SEED),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, min_samples_leaf=3, class_weight="balanced_subsample",
            n_jobs=-1, random_state=SEED),
        "Gradient Boosting": HistGradientBoostingClassifier(
            class_weight="balanced", random_state=SEED),
    }


PARAM_GRIDS = {
    "Logistic Regression": {"model__C": [0.01, 0.03, 0.1, 0.3, 1, 3, 10]},
    "Random Forest": {
        "model__n_estimators": [200, 400],
        "model__max_depth": [4, 6, 8, None],
        "model__min_samples_leaf": [1, 3, 5],
        "model__max_features": ["sqrt", 0.3],
    },
    "Gradient Boosting": {
        "model__learning_rate": [0.03, 0.05, 0.1],
        "model__max_depth": [2, 3, None],
        "model__max_leaf_nodes": [8, 15, 31],
        "model__min_samples_leaf": [20, 40],
        "model__l2_regularization": [0, 1, 10],
    },
}


def compare_models(X_train, y_train, cv_splits=5) -> pd.DataFrame:
    """Stratified CV on the training set only; the test set stays untouched."""
    cv = StratifiedKFold(cv_splits, shuffle=True, random_state=SEED)
    scoring = {"roc_auc": "roc_auc", "pr_auc": "average_precision",
               "recall": "recall", "precision": "precision", "f1": "f1"}
    rows = {}
    for name, est in candidates().items():
        res = cross_validate(make_pipeline(est, X_train), X_train, y_train,
                             cv=cv, scoring=scoring, n_jobs=1)
        rows[name] = {m: res[f"test_{m}"].mean() for m in scoring}
        rows[name]["roc_auc_std"] = res["test_roc_auc"].std()
    return pd.DataFrame(rows).T.sort_values("roc_auc", ascending=False)


def tune(name, X_train, y_train, n_iter=15, cv_splits=5):
    cv = StratifiedKFold(cv_splits, shuffle=True, random_state=SEED)
    search = RandomizedSearchCV(
        make_pipeline(candidates()[name], X_train), PARAM_GRIDS[name],
        n_iter=n_iter, scoring="roc_auc", cv=cv, random_state=SEED,
        n_jobs=-1, refit=True)
    search.fit(X_train, y_train)
    return search
