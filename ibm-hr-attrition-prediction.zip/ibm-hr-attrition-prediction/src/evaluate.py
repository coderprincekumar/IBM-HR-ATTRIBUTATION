"""Test-set metrics, plots and permutation importance."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.metrics import (ConfusionMatrixDisplay, PrecisionRecallDisplay,
                             RocCurveDisplay, accuracy_score, average_precision_score,
                             confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)

from .config import FIGURES_DIR, SEED


def _save(fig, name):
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / name, dpi=150)
    plt.close(fig)


def metrics_at(y_true, proba, threshold) -> dict:
    pred = (proba >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred).ravel()
    return {
        "threshold": float(threshold),
        "accuracy": accuracy_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "recall": recall_score(y_true, pred),
        "f1": f1_score(y_true, pred),
        "roc_auc": roc_auc_score(y_true, proba),
        "pr_auc": average_precision_score(y_true, proba),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


def plot_model_comparison(cv_table: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(7, 3.5))
    cv_table[["roc_auc", "pr_auc", "recall"]].plot.barh(ax=ax)
    ax.set_title("Model comparison (5-fold CV on training set)")
    ax.invert_yaxis()
    _save(fig, "05_model_comparison.png")


def plot_curves(model, X_test, y_test):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    RocCurveDisplay.from_estimator(model, X_test, y_test, ax=axes[0])
    axes[0].plot([0, 1], [0, 1], "k--", lw=1)
    axes[0].set_title("ROC curve (test set)")
    PrecisionRecallDisplay.from_estimator(model, X_test, y_test, ax=axes[1])
    axes[1].axhline(y_test.mean(), color="k", ls="--", lw=1, label="No-skill")
    axes[1].legend()
    axes[1].set_title("Precision-Recall curve (test set)")
    _save(fig, "06_roc_pr_curves.png")


def plot_confusion(y_true, proba, threshold):
    fig, ax = plt.subplots(figsize=(4.5, 4))
    ConfusionMatrixDisplay.from_predictions(
        y_true, (proba >= threshold).astype(int), display_labels=["Stayed", "Left"],
        cmap="Blues", colorbar=False, ax=ax)
    ax.set_title(f"Confusion matrix (threshold {threshold:.2f})")
    _save(fig, "07_confusion_matrix.png")


def permutation_table(model, X_test, y_test, top=15) -> pd.DataFrame:
    """Permutation importance on the *raw* columns, so names are readable
    (JobRole, OverTime...) instead of one-hot fragments."""
    r = permutation_importance(model, X_test, y_test, scoring="roc_auc",
                               n_repeats=20, random_state=SEED, n_jobs=1)
    tbl = pd.DataFrame({"feature": X_test.columns, "importance": r.importances_mean,
                        "std": r.importances_std})
    tbl = tbl.sort_values("importance", ascending=False).head(top)
    fig, ax = plt.subplots(figsize=(7, 5.5))
    ax.barh(tbl["feature"], tbl["importance"], xerr=tbl["std"], color="#4C72B0")
    ax.invert_yaxis()
    ax.set_xlabel("Drop in test ROC-AUC when the feature is shuffled")
    ax.set_title("Top features (permutation importance)")
    _save(fig, "08_permutation_importance.png")
    return tbl.reset_index(drop=True)


def plot_roi(strategies: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(8, 3.8))
    vals = strategies["net_benefit"]
    ax.barh(vals.index, vals.values, color=["#55A868" if v >= 0 else "#C44E52" for v in vals])
    ax.axvline(0, color="black", lw=1)
    ax.invert_yaxis()
    ax.set_xlabel("Net benefit on test set (USD)")
    ax.set_title("Retention strategy comparison")
    _save(fig, "09_roi_strategies.png")
