"""Exploratory data analysis: figures + auto-generated insights (nothing hard-coded)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from .config import EDA_CATEGORICAL, EDA_NUMERIC, FIGURES_DIR, REPORTS_DIR, TARGET

sns.set_theme(style="whitegrid")
PALETTE = {0: "#4C72B0", 1: "#C44E52"}


def _save(fig, name):
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / name, dpi=150)
    plt.close(fig)


def plot_target(df):
    fig, ax = plt.subplots(figsize=(4.5, 4))
    counts = df[TARGET].value_counts().sort_index()
    ax.bar(["Stayed", "Left"], counts.values, color=[PALETTE[0], PALETTE[1]])
    for i, v in enumerate(counts.values):
        ax.text(i, v, f"{v}\n({v / len(df):.1%})", ha="center", va="bottom")
    ax.set_title("Class balance")
    ax.set_ylim(0, counts.max() * 1.18)
    _save(fig, "01_class_balance.png")


def plot_attrition_by_category(df):
    cols = [c for c in EDA_CATEGORICAL if c in df.columns]
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    overall = df[TARGET].mean()
    for ax, col in zip(axes.ravel(), cols):
        rate = df.groupby(col)[TARGET].mean().sort_values()
        ax.barh(rate.index.astype(str), rate.values * 100, color="#C44E52")
        ax.axvline(overall * 100, color="black", ls="--", lw=1)
        ax.set_title(f"Attrition rate by {col}")
        ax.set_xlabel("% who left (dashed = company average)")
    _save(fig, "02_attrition_by_category.png")


def plot_numeric_boxplots(df):
    cols = [c for c in EDA_NUMERIC if c in df.columns]
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    for ax, col in zip(axes.ravel(), cols):
        sns.boxplot(data=df, x=TARGET, y=col, hue=TARGET, palette=PALETTE,
                    legend=False, ax=ax)
        ax.set_xticks([0, 1], ["Stayed", "Left"])
        ax.set_xlabel("")
        ax.set_title(col)
    _save(fig, "03_numeric_vs_attrition.png")


def plot_correlation(df):
    corr = df.select_dtypes("number").corr()
    fig, ax = plt.subplots(figsize=(12, 10))
    sns.heatmap(corr, cmap="RdBu_r", center=0, ax=ax, cbar_kws={"shrink": 0.7})
    ax.set_title("Correlation matrix (numeric features)")
    _save(fig, "04_correlation_heatmap.png")


def insights(df, min_group=30) -> str:
    """Headline findings computed directly from the data."""
    overall = df[TARGET].mean()
    lines = [
        "# EDA insights (auto-generated)\n",
        f"- Employees: **{len(df):,}**; overall attrition rate: **{overall:.1%}**.",
        "- Only a minority of employees leave, so accuracy is misleading: a model "
        "that predicts 'everyone stays' already scores high. Models are judged on "
        "ROC-AUC, PR-AUC and recall for leavers instead.\n",
        f"## Highest / lowest attrition groups (groups with >= {min_group} employees)\n",
    ]
    for col in EDA_CATEGORICAL:
        if col not in df.columns:
            continue
        g = df.groupby(col)[TARGET].agg(["mean", "size"])
        g = g[g["size"] >= min_group].sort_values("mean")
        if g.empty:
            continue
        hi, lo = g.iloc[-1], g.iloc[0]
        lines.append(
            f"- **{col}**: highest = *{g.index[-1]}* ({hi['mean']:.1%}, n={int(hi['size'])}); "
            f"lowest = *{g.index[0]}* ({lo['mean']:.1%}, n={int(lo['size'])})."
        )
    lines.append("\n## Numeric features: median for stayers vs leavers\n")
    for col in EDA_NUMERIC:
        if col in df.columns:
            m = df.groupby(TARGET)[col].median()
            lines.append(f"- **{col}**: stayed = {m[0]:,.1f}, left = {m[1]:,.1f}.")
    corr = df.select_dtypes("number").corr()[TARGET].drop(TARGET).sort_values()
    lines.append("\n## Strongest linear correlations with attrition\n")
    for name in list(corr.index[:3]) + list(corr.index[-3:]):
        lines.append(f"- {name}: {corr[name]:+.2f}")
    lines.append("\n> Correlation is not causation: these are patterns in the data, "
                 "not proof of why people leave.")
    return "\n".join(lines)


def run_eda(df):
    plot_target(df)
    plot_attrition_by_category(df)
    plot_numeric_boxplots(df)
    plot_correlation(df)
    text = insights(df)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    (REPORTS_DIR / "eda_insights.md").write_text(text, encoding="utf-8")
    return text
