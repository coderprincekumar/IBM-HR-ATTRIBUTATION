"""Central configuration: paths, column names and business assumptions."""
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA = ROOT / "data" / "raw" / "WA_Fn-UseC_-HR-Employee-Attrition.csv"
REPORTS_DIR = ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"
MODELS_DIR = ROOT / "models"

TARGET = "Attrition"
SEED = 42
TEST_SIZE = 0.20

# Constant columns (EmployeeCount, Over18, StandardHours) carry no signal;
# EmployeeNumber is just a row ID and would let a model memorise employees.
DROP_COLS = ["EmployeeCount", "EmployeeNumber", "Over18", "StandardHours"]

EDA_CATEGORICAL = [
    "OverTime", "JobRole", "Department", "MaritalStatus",
    "BusinessTravel", "EducationField",
]
EDA_NUMERIC = [
    "Age", "MonthlyIncome", "YearsAtCompany",
    "DistanceFromHome", "TotalWorkingYears", "YearsSinceLastPromotion",
]


@dataclass(frozen=True)
class BusinessAssumptions:
    """Assumptions behind the ROI estimate. These are NOT in the dataset:
    change them to match a real company and re-run.
    """
    # Cost to replace a leaver as a multiple of annual salary (recruiting,
    # onboarding, lost productivity). 1.5x is a common rule of thumb.
    replacement_cost_multiplier: float = 1.5
    # Cost of a retention action per flagged employee (pay adjustment, role change,
    # development plan, manager time). If this is tiny compared with the replacement
    # cost, 'intervene on everyone' beats any model - see the sensitivity table.
    intervention_cost: float = 5_000.0
    # Share of flagged would-be leavers who stay because of the action
    intervention_success_rate: float = 0.30
